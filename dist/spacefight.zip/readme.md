20090507

Copyright (C) 2009 by Mike Brent
This program is not public domain and may
not be sold without prior arrangement.
It may not be distributed on images sold
for a 'copy fee' either.
Getting permission is easy: mbrent@harmlesslion.com

Made with BATARI BASIC.

Earth ships are:
-Cargo ships
-Butterfly ships
-Space Shuttles
-Starbases

Enemy ships
-Sputniks
-Flying saucers
-Fighter ships
-Lightbulbs ;)

Up and Down to change speed
Left and Right to change shields
When a ship is displayed, press fire to attack it, or wait to let it pass.

If you do not destroy an enemy ship, it will shoot you as it leaves.
If you do destroy an enemy ship, you get 100-400 points

If you shoot an Earth ship, you lose 300 points.
If you shoot a Starbase, you lose ALL your points.

If you do not shoot the Starbase, your missiles and fuel are refilled, and damage is repaired.

The four guages are:

Fuel   Shields
  Warning
Speed  Damage

Missiles are displayed on either side of the score.

Damage is caused by impacts, repairs automatically, and takes the least fuel during repair.
Shield reduces the damage done by impacts, but takes the most fuel.
Speed increases how often you will encounter ships, and takes a medium amount of fuel.

Fuel is decreased by all of the above. When fuel is exhausted, the game ends.

Regarding the source, "my_kernel.asm" is meant to go in place of "std_kernel.asm",
and it's /only/ useful in this game. Is there a proper way to do BATARI BASIC kernel
hacking? Also, I still don't understand a fair bit of what's going on. ;)
